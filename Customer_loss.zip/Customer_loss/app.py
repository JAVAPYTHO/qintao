import pandas as pd
import numpy as np
import streamlit as st
from sklearn.model_selection import train_test_split, cross_val_score
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier
from sklearn.svm import SVC
from sklearn.tree import DecisionTreeClassifier
from sklearn.naive_bayes import GaussianNB
from xgboost import XGBClassifier
from sklearn.metrics import accuracy_score, roc_auc_score, confusion_matrix, classification_report, ConfusionMatrixDisplay, roc_curve
from sklearn.preprocessing import LabelEncoder
import shap
import matplotlib.pyplot as plt
import seaborn as sns
import warnings
warnings.filterwarnings('ignore')

# 设置 Streamlit 标题
st.title("客户流失预测系统")

# 数据加载模块
st.sidebar.header("数据加载")
uploaded_file = st.sidebar.file_uploader("上传数据文件 (CSV 格式)", type=["csv"])

if uploaded_file is not None:
    # 加载数据
    data = pd.read_csv(uploaded_file)
    st.write("### 数据预览")
    st.write(data.head())

    # 特征和目标分离
    X = data.drop(columns=['churn'])
    y = data['churn']

    # 编码类别型特征
    categorical_columns = X.select_dtypes(include=['object']).columns
    encoder = LabelEncoder()
    for col in categorical_columns:
        X[col] = encoder.fit_transform(X[col])

    # 拆分训练集和测试集
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, random_state=42, stratify=y
    )

    # 模型选择模块
    st.sidebar.header("模型选择")
    model_name = st.sidebar.selectbox(
        "选择模型",
        ["逻辑回归", "随机森林", "支持向量机", "决策树", "朴素贝叶斯", "XGBoost"]
    )

    # 模型初始化
    if model_name == "逻辑回归":
        model = LogisticRegression(max_iter=1000, random_state=42)
    elif model_name == "随机森林":
        model = RandomForestClassifier(random_state=42)
    elif model_name == "支持向量机":
        model = SVC(probability=True, random_state=42)
    elif model_name == "决策树":
        model = DecisionTreeClassifier(random_state=42)
    elif model_name == "朴素贝叶斯":
        model = GaussianNB()
    elif model_name == "XGBoost":
        model = XGBClassifier(use_label_encoder=False, eval_metric='logloss', random_state=42)

    # 模型训练
    st.sidebar.header("模型训练")
    if st.sidebar.button("开始训练"):
        model.fit(X_train, y_train)

        # 模型性能评估
        st.write(f"### 模型：{model_name}")
        y_pred = model.predict(X_test)
        y_pred_proba = model.predict_proba(X_test)[:, 1]

        # 准确率与AUC
        accuracy = accuracy_score(y_test, y_pred)
        auc = roc_auc_score(y_test, y_pred_proba)
        st.write(f"准确率: {accuracy:.4f}")
        st.write(f"AUC: {auc:.4f}")

        # 混淆矩阵
        st.write("### 混淆矩阵")
        cm = confusion_matrix(y_test, y_pred)
        disp = ConfusionMatrixDisplay(confusion_matrix=cm)
        disp.plot(cmap='Blues', values_format='d')
        st.pyplot(plt)

        # ROC 曲线
        st.write("### ROC 曲线")
        fpr, tpr, _ = roc_curve(y_test, y_pred_proba)
        plt.figure(figsize=(8, 6))
        plt.plot(fpr, tpr, label=f"ROC curve (AUC = {auc:.4f})", color='darkorange')
        plt.plot([0, 1], [0, 1], linestyle='--', color='navy')
        plt.xlabel('False Positive Rate')
        plt.ylabel('True Positive Rate')
        plt.title('ROC Curve')
        plt.legend(loc="lower right")
        st.pyplot(plt)

        # 特征重要性 (仅适用于支持特征重要性的模型)
        if model_name in ["随机森林", "决策树", "XGBoost"]:
            st.write("### 特征重要性")
            feature_importances = model.feature_importances_
            importance_df = pd.DataFrame({
                'Feature': X.columns,
                'Importance': feature_importances
            }).sort_values(by='Importance', ascending=False)
            st.bar_chart(importance_df.set_index('Feature'))

        # SHAP 分析 (仅适用于支持 SHAP 的模型)
        if model_name == "XGBoost":
            st.write("### SHAP 分析")
            shap.initjs()
            explainer = shap.TreeExplainer(model)
            shap_values = explainer.shap_values(X_test)

            # 全局特征重要性
            st.write("#### 全局特征重要性")
            shap.summary_plot(shap_values, X_test, show=False)
            st.pyplot(plt)

            # 单个样本分析
            st.write("#### 单个样本分析")
            sample_index = st.slider("选择样本索引", 0, X_test.shape[0] - 1, 0)
            st.write("#### 单个样本特征贡献")
            shap.force_plot(
                explainer.expected_value,
                shap_values[sample_index, :],
                X_test.iloc[sample_index, :],
                matplotlib=True
            )
            st.pyplot(plt)
